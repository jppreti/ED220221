#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Hash.h"
#include "log.h"



typedef struct Palavra {
    char p[30];
}Palavra;

bool comparaChaves(void *key, void *data) {
    log_trace("Entrando em comparaChaves");
    char *chave = (char*)key;
    log_debug("chave: %s", chave);
    Palavra *c = (Palavra*)data;
    log_debug("cliente c: %p", c);
    log_trace("Saindo de comparaChaves");
    
    return (strcmp (chave, c->p) == 0)?true:false;
}

void printCliente(void *data) {
    Palavra *cliente = (Palavra*)data;
    printf("  %s", cliente->p);
}

float getEscala(HashStruct hashes){
	int count, maior;
	float escala;
	for (count = 0; count<MAX; count++ ){
        if (maior < hashes.hashes[count].size)maior = hashes.hashes[count].size;
    }
    escala = 255/maior;
    return escala;
}

int main() {
	FILE *arq;
	char linha[30];
	int i;
	char *resul;
    arq = fopen("ListaDePalavrasPT.txt", "rt");
    if (arq == NULL)printf("Problemas na CRIACAO do arquivo \n");
	
	log_set_level(LOG_WARN);
    HashStruct hashes, hshs2;
    initHash(&hashes);initHash(&hshs2);

 //	Palavra *cliente = (Palavra*) get(&hashes,c->p,comparaChaves);
 	
	while (!feof(arq))//(fgets(linha, sizeof(linha), arq) != NULL) 
    {
    	/* note como nao precisamos especificar uma nova linha, o fgets ja a inclui na string linha quando a encontra */
        //printf("%s", &linha);
        Palavra *c = (Palavra *)malloc(sizeof(Palavra));
        resul= fgets(linha, 30, arq);
        if(resul)
        {
            // printf("%d: %s", i, linha);
    		strcpy(c->p, linha);
    		//printf("%s", linha);
    		put(&hashes, c->p, c, comparaChaves);
    		put2(&hshs2, c->p, c, comparaChaves);
        }
    	i++;
	}
    fclose(arq);
    int count;
    float escala = getEscala(hashes); // Temos agora a escala da cor por colisao conhecida.
    
    int intensidade[MAX];
    for (count = 0; count<MAX; count++ ){
    	intensidade[count] = escala * hashes.hashes[count].size;
	} // Temos agora o vetor da escala do hash
       
    
    arq = NULL;
    arq = fopen("Pixel.ppm", "w");
    if (arq == NULL)printf("Problemas na CRIACAO do arquivo\n");
    //
    int count2, count3, count4;
    fputs("P3\n320 320\n255\n", arq);
    
    //*
    for(count = 0; count<MAX;count+=32){
        for(count4 = 0; count4<10;count4++){
            for(count2 = 0;count2<32;count2++){
                for(count3 = 0;count3<10;count3++){
                   fprintf(arq,"%d 0 %d \n", intensidade[count+count2], intensidade[count+count2]);
                }
            }
        }
        
    }
    
    fclose(arq); // segundo arquivo
    escala = getEscala(hshs2);
    //printf("%d",escala);
    //for(i = 0; i<MAX; i++)
    for (count = 0; count<MAX; count++ ){
    	intensidade[count] = escala * hshs2.hashes[count].size;
	} // Temos agora o vetor da escala do hash
       
    
    arq = NULL;
    arq = fopen("Pixel2.ppm", "w");
    if (arq == NULL)printf("Problemas na CRIACAO do arquivo\n");
    //
    fputs("P3\n320 320\n255\n", arq);
    
    //*
    for(count = 0; count<MAX;count+=32){
        for(count4 = 0; count4<10;count4++){
            for(count2 = 0;count2<32;count2++){
                for(count3 = 0;count3<10;count3++){
                   fprintf(arq,"%d 0 %d \n", intensidade[count+count2], intensidade[count+count2]);
                }
            }
        }
        
    }
    fclose(arq);
    return 0;
}
